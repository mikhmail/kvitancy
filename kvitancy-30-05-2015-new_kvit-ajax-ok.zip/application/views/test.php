ajax view... <?php if(isset($data)) echo $data;?>
<br /><br />
Ajax Controllers work great.
<br /><br /><br />
View: <a href='ajax.php?test/test2'>test2</a>