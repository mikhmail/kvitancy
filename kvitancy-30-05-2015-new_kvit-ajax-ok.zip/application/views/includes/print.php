<!DOCTYPE html> 
<html lang="en-US">
<head>
  <title>Print</title>
  <meta charset="utf-8">
  <link href="<?php echo base_url(); ?>assets/css/admin/global.css" rel="stylesheet" type="text/css">
  <script src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/admin.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.calculation.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/func.js"></script>
</head>
<body>
<?php $this->load->view($main_content); ?>