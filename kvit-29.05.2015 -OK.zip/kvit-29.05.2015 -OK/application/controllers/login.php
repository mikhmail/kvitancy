<?php

class Login extends CI_Controller {

    /**
    * Check if the user is logged in, if he's not, 
    * send him to the login page
    * @return void
    */
		// login cont and login view - one login app for login all users.
		// in admin panal check func is_admin() for admin assecc...mikh!!!
		
	function index()
	{
		if($this->session->userdata('is_logged_in')){
			//var_dump($this->session->userdata);die;
			//redirect('admin/users');
			$this->load->view('about');	
        }else{
        	$this->load->view('login');	
        }
	}

    
	   /**
    * encript the password 
    * @return mixed
    */	
    function __encrip_password($password) {
        return md5($password);
    }	

    /**
    * check the username and the password with the database
    * @return void
    */
	function validate_credentials()
	{	

		$this->load->model('Users_model');

		$user_name = $this->input->post('user_name');
		$password = $this->__encrip_password($this->input->post('password'));

		$is_valid = $this->Users_model->validate($user_name, $password);
		
		
		if($is_valid)
		{  
		$user_id = $this->Users_model->get_user_id_by_user_name($user_name);
			$data = array(
				'user_id' => $user_id,
				'user_name' => $user_name,
				'is_logged_in' => true
			);
			$this->session->set_userdata($data);
			redirect('/');
		}
		else // incorrect username or password
		{
			$data['message_error'] = TRUE;
			$this->load->view('user/login', $data);	
		}
	}	

	function logout()
	{
		$this->session->sess_destroy();
		redirect('/');
	}
	
	function cache_delete()
	{
		$this->db->cache_delete_all();
		$this->session->set_flashdata('flash_message', 'cache deleted');
		redirect('/admin');
	}
	
	

}