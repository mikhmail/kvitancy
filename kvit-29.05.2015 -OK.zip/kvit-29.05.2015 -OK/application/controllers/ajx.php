<?php

class Ajx extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('kvitancy_model');
	}
	
	
	
	function change_status ($id_sost, $id_kvitancy)
	{
	
	
	if ($id_sost == 1) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => ''
					   );
	}
	elseif ($id_sost == 3) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => ''
					   );
	}
	elseif ($id_sost == 4) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => date("Y-m-j"),
					   'date_vydachi' => ''
					   );
	}
	elseif ($id_sost == 6) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => date("Y-m-j"),
					   'date_vydachi' => ''
					   );
	}
	elseif ($id_sost == 7 or $id_sost == 8 or $id_sost == 9) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => date("Y-m-j")
					   );
	}						
	elseif ($id_sost == 10) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => ''
					   );
	}							
	elseif ($id_sost == 17) {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => ''
					   );
	}
	else {
	$data = array(
					   'id_sost' => $id_sost,
					   'date_okonchan' => '',
					   'date_vydachi' => ''
					   );
	}	  
		
		
		
			
		$this->db->where('id_kvitancy', $id_kvitancy);
		$ret = $this->db->update('kvitancy', $data);
		
		
	}
		
	
	function change_mechanic ($id_meh, $id_kvitancy, $update_user=NULL)
	{
		$data = array(
					   'id_mechanic' => $id_meh,
					   'update_time' => date("j-m-Y, H:i:s"),
					   'update_user' => $update_user
					   );
	
	
		$this->db->where('id_kvitancy', $id_kvitancy);	
		$ret = $this->db->update('kvitancy', $data);
	}
	
	function add_comment ()
	{	
	//var_dump(($this->input->post('comment')));die;
		$user_id = $this->session->userdata['user_id'];
		$date = date("Y-m-d H:i:s");
		
		if ($this->input->post('comment')) {
		$data = array(
					   'date' => $date,
					   'comment' => $this->input->post('comment'),
					   'id_user' => $user_id,
					   'id_kvitancy' => $this->input->post('id')
					   );
		
		$ret = $this->db->insert('comments', $data);
		if ($ret) {
		
		$arr = $this->kvitancy_model->get_comment_by_id(mysql_insert_id());
		foreach($arr as $rowc)
				{	echo '<li id=li_' . $rowc['id_comment'] . '>' . $rowc['date'] . ' ' . $rowc['first_name'] . ' ' . $rowc['last_name'] . ' aka ' . $rowc['user_name'] . ' пишет: ' . '<br><font color="#0066CC"><b>' . $rowc['comment'] . '</b></font>';
				}
			}
		}
		else echo 'Надо ввести сообщение';
	}
	
	function delete_comment ()
	{	

		$this->db->delete('comments', array('id_comment' => $this->input->post('id_comment')));
			if ($this->db->affected_rows() > 0) return TRUE;
		
        return FALSE;
		}
	
}