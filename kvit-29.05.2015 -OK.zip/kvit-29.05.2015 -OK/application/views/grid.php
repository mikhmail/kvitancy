<html>
  <head>

    <link href="themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
	<link href="Scripts/jtable/themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
	
	<script src="scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="Scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
	
  </head>
  <body>
  
 <div class="filtering">
    <form>
        Name: <input type="text" name="name" id="name" />
        
        <button type="submit" id="LoadRecordsButton">Load records</button>
    </form>
</div>
 
<div id="StudentTableContainer"></div>
  
	<div id="PeopleTableContainer" style="width: 600px;"></div>
	<script type="text/javascript">

		$(document).ready(function () {

		    //Prepare jTable
			$('#PeopleTableContainer').jtable({
				title: 'Table of people',
				paging: true,
				pageSize: 5,
				sorting: true,
				defaultSorting: 'Name ASC',
				actions: {
					//listAction:   'grid/show',
					
					listAction: function (postData, jtParams) {
                    console.log("Loading from custom function...");
                    return $.Deferred(function ($dfd) {
                        $.ajax({
                            url: 'grid/show',
                            type: 'POST',
                            dataType: 'json',
                            data: postData,
                            success: function (data) {
                                $dfd.resolve(data);
                            },
                            error: function () {
                                $dfd.reject();
                            }
                        });
                    });
                },
					
					createAction: 'grid/create',
					updateAction: 'grid/update',
					deleteAction: 'grid/delete'
				},
				fields: {
					PersonId: {
						key: true,
						create: false,
						edit: true,
						list: true
					},
					Name: {
						title: 'Author Name',
						width: '40%'
					},
					Age: {
						title: 'Age',
						width: '20%'
					},
					RecordDate: {
						title: 'Record date',
						width: '30%',
						type: 'date',
						create: false,
						edit: false
					}
				}
			});


 //Re-load records when user click 'load records' button.
        $('#LoadRecordsButton').click(function (e) {
            e.preventDefault();
            $('#PeopleTableContainer').jtable('load', {
                name: $('#name').val()
                
            });
        });
 
        //Load all records when page is first shown
        $('#LoadRecordsButton').click();
			
			
		});

	</script>
 
  </body>
</html>
<?php

?>