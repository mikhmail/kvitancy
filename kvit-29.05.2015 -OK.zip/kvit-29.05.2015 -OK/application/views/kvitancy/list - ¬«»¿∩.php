    <div class="container top">

      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("kvitancy"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
       <a href="<?php echo site_url('kvitancy/'. strtolower(ucfirst($this->uri->segment(2)))); ?>">
            <?php echo ucfirst($this->uri->segment(2));?>
          </a>
      </ul>

      <div class="page-header users-header">
        <h2>
          <?php echo ucfirst($this->uri->segment(2));?> 
          <a  href="#" class="btn btn-success" id="new-order-button">Добавить</a>
        </h2>
      </div>
      
      <div class="row">
        <div class="span12 columns">
          <div class="well">
           <p>Найдено <?=$count_kvitancys?> квитанций</p>
		   
            <?php
           //var_dump($diag);die;
		   
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
           
			
            echo form_open('kvitancy', $attributes);
     
	  echo form_label('№квит:', 'id_kvitancy');
				echo form_input('id_kvitancy', $id_kvitancy_selected);
echo '<br>';
	 
              echo form_label('Поиск:', 'search_string');
				echo form_input('search_string', $search_string_selected);
echo '<br>';
				echo form_label('Дата: ');
				$options_date = array('date_priemka' => 'Приемка', 'date_vydachi' => 'Выдачи', 'date_okonchan' => 'Окон.ремонта');
				
				  echo form_dropdown('date', $options_date, $date_selected, 'class="span2"');
	
				
			echo form_label('C: ');
					
				echo form_date('start_date', $start_date);
				
              echo form_label('По: ');
				echo form_date('end_date', $end_date);

echo '<br>';

				echo form_label('Приемка: ');
				$options_id_sc = array('' => "Выбрать");
            
					foreach ($sc as $array) {
						$options_id_sc[$array['id_sc']] = $array['name_sc'];
					}
				
				  echo form_dropdown('id_sc', $options_id_sc, $id_sc_selected, 'class="span2"');
	
echo '<br>';

				//var_dump($meh);die;
				echo form_label('Механик: ');
								$options_id_meh = array('' => "Выбрать");
							
									foreach ($meh as $array) {
										$options_id_meh[$array['id']] = $array['user_name'];
									}
								
								  echo form_dropdown('id_mechanic', $options_id_meh, $id_mechanic_selected, 'class="span2"');
					
echo '<br>';

		//var_dump($meh);die;
				echo form_label('Бренд: ');
												$options_proizvoditel = array('' => "Выбрать");
											
													foreach ($proizvoditel as $array) {
														$options_proizvoditel[$array['id_proizvod']] = $array['name_proizvod'];
													}
												
												  echo form_dropdown('id_proizvod', $options_proizvoditel, $id_proizvod_selected, 'class="span2"');
									
echo '<br>';


//var_dump($meh);die;
				echo form_label('Аппарат: ');
												$options_ap = array('' => "Выбрать");
											
													foreach ($ap as $array) {
														$options_ap[$array['id_aparat']] = $array['aparat_name'];
													}
												
												  echo form_dropdown('id_aparat', $options_ap, $id_aparat_selected, 'class="span2"');
									
echo '<br>';


//var_dump($meh);die;
				echo form_label('Состояние: ');
												$options_sost = array('' => "Выбрать");
											
													foreach ($sost as $array) {
														$options_sost[$array['id_sost']] = $array['name_sost'];
													}
												$sost_selected = 'date_vydachi';
												  echo form_dropdown('id_sost', $options_sost, $id_sost_selected, 'class="span2"');
									
echo '<br>';


              $options_order_type = array('Asc' => 'С начала', 'Desc' => 'С конца');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span2"');

			  
			  $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Поиск');
              echo form_submit($data_submit);

            echo form_close();
            ?>

          </div>

          <table class="table-bordered table-hover">
            <thead>
              <tr class="header">
                <th class="">#</th>
				<th class="">Приемка</th>
				<th class="">Выдача</th>
				<th class="">Сервис</th>
				
				
                <th class="">ФИО</th>
				<th class="">Аппарат</th>
				
				<th class="">Неисправность</th>
				<th class="">Статус</th>
				<th class="">Механик</th>
				
				<th class="">Управление</th>
				
				
				
              </tr>
            </thead>
            <tbody>
              <?php
			  
			  //var_dump($kvitancys);die;	
			  
			  if (count($kvitancys)>0) {
			  
			   //var_dump($kvitancys);die;
			  
              foreach($kvitancys as $row)
              {
			  
			  //var_dump($row);die;
			  
                echo '<tr class="success" id = '.$row['id_kvitancy'].'>';
				echo '<td>'.$row['id_kvitancy'].'</td>';
                echo '<td>'.$row['date_priemka'].'</td>';
                echo '<td>'.$row['date_vydachi'].'</td>';
                
                echo '<td>'.$row['name_sc'].'</td>';
                echo '<td>'.$row['fam'].' '.$row['imya'].' '.$row['phone'].'</td>';
				echo '<td>'.$row['aparat_name'].' '.$row['name_proizvod'].' '.$row['model'].'</td>';
				
				echo '<td>'.$row['neispravnost'].'</td>';
				
				echo '<td>' . form_dropdown($row['id_kvitancy'], $options_sost, $row['id_sost'], 'id=status_' . $row['id_kvitancy'] . ' class="span2"') . '</td>';						
				
				echo '<td>' . form_dropdown($row['id_kvitancy'], $options_id_meh, $row['id'], 'id=meh_' . $row['id_kvitancy'] . ' class="span2"') . '</td>';						
				
				
				
				
                echo '<td class="crud-actions">
                  <a href="'.site_url().'kvitancy/update/'.$row['id_kvitancy'].'" class="btn btn-info">Изменить</a>  
                  <a href="'.site_url().'kvitancy/printing/'.$row['id_kvitancy'].'" class="btn btn-danger" target="_blank">Печать</a>
				  <a href="'.site_url().'kvitancy/printing_check/'.$row['id_kvitancy'].'" class="btn btn-danger" target="_blank">Печать чека</a>
				  
                </td>';
                echo '</tr>';
				
				echo '<tr><td colspan="10">';
				$comments = $this->kvitancy_model->get_comments($row['id_kvitancy']);
				
				echo '<ul id=' . 'ul_' . $row['id_kvitancy'] . '>';
				foreach($comments as $rowc)
              {
			 
			  echo '<li id=li_' . $rowc['id_comment'] . '>' . $rowc['date'] . ' ' . $rowc['first_name'] . ' ' . $rowc['last_name'] . ' aka ' . $rowc['user_name'] . ' пишет: ' . '<br><font color="#0066CC"><b>' . $rowc['comment'] . '</b></font>';

			  }
				echo '</ul>'?>
				
				<textarea rows="3" name="comment_<?=$row['id_kvitancy']?>">
				<?print_r($this->session->userdata['user_id'])?>
				</textarea><br>
				
				<input type="button" name="comment" id="comment_<?=$row['id_kvitancy']?>" value="Добавить комментарий"/>
<?
				echo '</td></tr>';
				
              }
			}
              ?>      
            </tbody>
          </table>

          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>
		  

      </div>
    </div>
	