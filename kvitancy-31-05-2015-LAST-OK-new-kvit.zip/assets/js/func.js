
function anichange (obj) {
							var objName = $(obj).next();
							var objPrev = $(obj).prev();
							
								 if ( $(objName).css('display') == 'none' ) {
								 $(objName).animate({height: 'show'}, 400);
								 $(objPrev).css({'background-position':"-11px 0"});
								 } else {
								 $(objName).animate({height: 'hide'}, 200);
								 $(objPrev).css({'background-position':"0 0"});
								 }
								}

$(document).ready(function(){


// смена статуса
$('select[id^=status_]').change(function(){
var status = $('#'+this.id+' option:selected').val();
var id = this.name;
		$.ajax({
		  url: "/ajx/change_status/"+status+"/"+id+"",
		  success: function(data) {
			
			 $("#status_"+id+"").fadeOut("slow");
			 $("#status_"+id+"").fadeIn();
		  }
		});
	delete status;
	delete id;
	});
	
// смена механика	
$('select[id^=meh_]').change(function(){

var status = $('#'+this.id+' option:selected').val();
var id = this.name;
		$.ajax({
		  url: "/ajx/change_mechanic/"+status+"/"+id+"",
		  success: function(data) {
			
			 $("#meh_"+id+"").fadeOut("slow");
			 $("#meh_"+id+"").fadeIn();
		  }
		});
	delete status;
	delete id;
	});
		
// добавить комментарий	
$('input[name=comment]').click(function(){
var comment = $('textarea[name='+this.id+']').val();
var arr = this.id.split('_');
var id = parseInt(arr[1]);
//alert(id);

$.post("/ajx/add_comment", {id:id, comment:comment})
	.done(function(data) {
	
	$("#ul_"+id+"").append(data);
	$('textarea[name=comment_'+id+']').val('');
		});
	});
	

// удалить комментарий	
$('input[id^=dell_comment]').click(function(){
var id_comment = this.name;
//alert (id_comment);die;
$.post("/ajx/delete_comment", {id_comment:id_comment})
	.done(function(data) {
	$("#li_"+id_comment+"").remove();
		});
	});


	
// модальное окно новой квитанции
$('a#new-order-button').click( function(event){ // ловим клик по ссылки с id="go"
        event.preventDefault(); // выключаем стандартную роль элемента
        $('#overlay').fadeIn(400, // сначала плавно показываем темную подложку
            function(){ // после выполнения предъидущей анимации
                $('#modal_form') 
                    .css('display', 'block') // убираем у модального окна display: none;
                    .animate({opacity: 1, top: '50%'}, 200); // плавно прибавляем прозрачность одновременно со съезжанием вниз
        });
    });
    /* Закрытие модального окна, тут делаем то же самое но в обратном порядке */
    $('#modal_close, #overlay').click( function(){ // ловим клик по крестику или подложке
        $('#modal_form')
            .animate({opacity: 0, top: '45%'}, 200,  // плавно меняем прозрачность на 0 и одновременно двигаем окно вверх
                function(){ // после анимации
                    $(this).css('display', 'none'); // делаем ему display: none;
                    $('#overlay').fadeOut(400); // скрываем подложку
                }
            );
    });

// добавить квитанцию	
$('input[name=new_kvit]').click(function(){

// kvitancy
var id_aparat = $("#id_aparat option:selected").val();
var id_proizvod = $("#id_proizvod option:selected").val();
var model = $('input[name=model]').val();
var ser_nomer = $('input[name=ser_nomer]').val();
var neispravnost = $('textarea[name=neispravnost]').val();
var komplektnost = $('textarea[name=komplektnost]').val();
var vid = $('textarea[name=vid]').val();
var id_remonta = $("#id_remonta option:selected").val();
var id_sc = $("#id_sc option:selected").val();
var primechaniya = $('textarea[name=primechaniya]').val();

//client
var fam = $('input[name=fam]').val();
var imya = $('input[name=imya]').val();
var otch = $('input[name=otch]').val();
var phone = $('input[name=phone]').val();
var email = $('input[name=email]').val();
var adres = $('input[name=adres]').val();

var where_id = $("#where_id option:selected").val();


$.post("/ajx/add_kvitancy", {
									id_aparat:id_aparat,
									id_proizvod:id_proizvod,
									model:model,
									ser_nomer:ser_nomer,
									neispravnost:neispravnost,
									komplektnost:komplektnost,
									vid:vid,
									id_remonta:id_remonta,
									id_sc:id_sc,
									primechaniya:primechaniya,
									fam:fam,
									imya:imya,
									otch:otch,
									phone:phone,
									email:email,
									adres:adres,
									where_id:where_id
									})

	
	
	.done(function(data) {
		var id_kvitancy = data;
					$('#modal_form')
						.animate({opacity: 0, top: '45%'}, 200,  // плавно меняем прозрачность на 0 и одновременно двигаем окно вверх
							function(){ // после анимации
								$(this).css('display', 'none'); // делаем ему display: none;
								$('#overlay').fadeOut(300); // скрываем подложку
							}
						);
			//window.open("/kvitancy/view/"+id_kvitancy+"");
			window.location = "/kvitancy/view/"+id_kvitancy+"";
	
		});	
	});

	
$("#add_aparat").click(function(){
		app = $("#add_aparat_name").val();
			
			$.post("/ajx/add_aparat", {aparat_name:app})
			.done(function(data) {
		//alert (data);
		if (data.match(/^[-\+]?\d+/) === null) {
			alert('Такой аппарат уже есть в базе!');
				$("#add_aparat_name").focus();
			} else {
			
			$("select#id_aparat").append('<option value="'+data+'" selected="selected">'+app+'</option>');
			$( "span[name='aparat_span']" ).hide();
			
		
			}
		});				
	});

$("#add_proizvod").click(function(){
		app = $("#add_proizvod_name").val();
			
			$.post("/ajx/add_proizvod", {proizvod_name:app})
			.done(function(data) {
		//alert (data);
		if (data.match(/^[-\+]?\d+/) === null) {
			alert('Такой бренд уже есть в базе!');
				$("#add_proizvod_name").focus();
			} else {
			
			$("select#id_proizvod").append('<option value="'+data+'" selected="selected">'+app+'</option>');
			$( "span[name='proizvod_span']" ).hide();
			
		
			}
		});				
	});	
	

//	
//	
//ready	
});

function look_apparat(inputString) {
                if(inputString.length > 10) {
                        $('#apparat_box').hide();
                } else {
                        $.post("/ajx/look_apparat", {queryString: ""+inputString+""}, function(data){
                                if(data.length > 2) {
                                        $('#apparat_box').show();
                                        $('#apparat_list').html(data);
                                }
                        });
                }
        } // lookup

		
function fill_apparat(thisValue) {
			
			var parts=new Array();
			var response = thisValue;
			
			parts = response.split('-');
			$("select#id_aparat").append('<option value="'+parts[0]+'" selected="selected">'+parts[1]+'</option>');
			$("select#id_aparat").attr("class","status");
			
			setTimeout("$('#apparat_box').hide();", 200);
 }
 
 
 function look_proizvod(inputString) {
                if(inputString.length > 10) {
                        $('#proizvod_box').hide();
                } else {
                        $.post("/ajx/look_proizvod", {queryString: ""+inputString+""}, function(data){
                                if(data.length > 2) {
                                        $('#proizvod_box').show();
                                        $('#proizvod_list').html(data);
                                }
                        });
                }
        } // lookup

		
function fill_proizvod(thisValue) {
			
			var parts=new Array();
			var response = thisValue;
			
			parts = response.split('-');
			$("select#id_proizvod").append('<option value="'+parts[0]+'" selected="selected">'+parts[1]+'</option>');
			$("select#id_proizvod").attr("class","status");
			
			
			setTimeout("$('#proizvod_box').hide();", 200);
 }