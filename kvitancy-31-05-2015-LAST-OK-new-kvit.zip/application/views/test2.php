<html>
<head>
<?php echo ajax()->init();?>
</head>
<body>
<div id='response'></div>
</body>
</html>