<?php
/**
 * Config file
 */

// count of tickets per page; кол-во заявок на странице;
$tickets_per_page=35;

//database setting
$hostname="%HOSTNAME%";
$username="%USERNAME%";
$password="%PASSWORD%";
$database="%DATABASE%";

?>