<?php

class Login extends CI_Controller {

	  public function __construct() {
        parent::__construct();

	}
		
	function index()
	{
		
		$install = FCPATH . 'install';
		/*	
		include(APPPATH.'config/database'.EXT);
		$dbname = $db['default']['database'];
		$user = $db['default']['username'];
		$pwd = $db['default']['password'];
		$host = $db['default']['hostname'];
		*/
		
		require $_SERVER['DOCUMENT_ROOT'].'/config.php';

		// The following values will probably need to be changed.
		$db['default']['username'] = $username;
		$db['default']['password'] = $password;
		$db['default']['database'] = $database;
		$db['default']['hostname'] = $hostname;
		
		$dsn = "mysqli://$username:$password@$hostname/$database";
		 
	// Load database and dbutil
		$this->load->database($dsn);
		$this->load->dbutil();
 
	// check connection details
	if(! $this->dbutil->database_exists($database))
	{
		// if connection details incorrect show error
		//echo 'Incorrect database information provided IN ' . APPPATH.'config/database'.EXT;
		//echo "<script language='JavaScript' type='text/javascript'>alert('Incorrect database information provided')</script>";
		//echo "<script language='JavaScript' type='text/javascript'>window.location.replace('/install')</script>";
		redirect(BASE_URL . 'install');
		exit;
		
	}
	

	elseif (file_exists($install)) {
			echo 'Delete Install folder ' . $install;
			echo "<script language='JavaScript' type='text/javascript'>alert('Delete Install folder')</script>";
			exit;
		} 
	
	
	else {
			if($this->session->userdata('is_logged_in')){
				redirect('tickets');
				}else{
					$this->load->view('login');	
					}
		}

	}

    
	   /**
    * encript the password 
    * @return mixed
    */	
    function __encrip_password($password) {
        return md5($password);
    }	

    /**
    * check the username and the password with the database
    * @return void
    */
	function validate_credentials()
	{	//var_dump($this->input->post());die;
		if ($user_name = $this->input->post('remember')) {
			$remember = 'true';
		}
		
		$this->load->model('Users_model');

		$user_name = $this->input->post('user_name');
		$password = $this->__encrip_password($this->input->post('password'));

		$is_valid = $this->Users_model->validate($user_name, $password);
		
		
		if($is_valid)
		{  
		$user_id = $this->Users_model->get_user_id_by_user_name($user_name);
		
		$user_arr = $this->Users_model->get_users_by_id($user_id);
		
		$id_group = $user_arr[0]["id_group"]; 
		$id_sc = $user_arr[0]["id_sc"];
        $show_my_tickets = $user_arr[0]["show_my_tickets"];
        $show_call_tickets = $user_arr[0]["show_call_tickets"];


            $data = array(
				'user_id' => $user_id,
				'user_name' => $user_name,
				'id_group' => $id_group,
				'user_id_sc' => $id_sc,
				'is_logged_in' => true,
                'show_call_tickets' => $show_call_tickets,
                'show_my_tickets' => $show_my_tickets
			);

        $remember = $this->input->post('remember');
		if($remember)
		{
        $data['new_expiration'] = 60*60*24*3;//3 days
        $this->session->sess_expiration = $data['new_expiration'];
		}
			//var_dump($data);die;
			$this->session->set_userdata($data);
			redirect('/');
		}
		else // incorrect username or password
		{
			$data['message_error'] = TRUE;
			$this->load->view('login', $data);
		}
	}	

	function logout()
	{
		$this->session->sess_destroy();
		redirect('/');
	}
	
	function cache_delete()
	{
		$this->db->cache_delete_all();
		$this->session->set_flashdata('flash_message', 'cache deleted');
		redirect('/admin');
	}
	
	

}