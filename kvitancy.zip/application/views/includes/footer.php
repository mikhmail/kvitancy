	<div id="footer">
		<hr>
		<div class="row-fluid">
            <div class="pull-right">
                <p align="right"><a href="#">Вернуться наверх</a></p>
            </div>
		</div>
	</div>
    <div id="ajaxloader"><img class="ajax-loader" src="<?php echo base_url(); ?>images/ajax-loader.gif"></div>
</body>
</html>